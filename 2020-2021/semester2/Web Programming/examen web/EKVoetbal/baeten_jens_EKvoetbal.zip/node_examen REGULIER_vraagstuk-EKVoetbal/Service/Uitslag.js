class Uitslag{

    constructor(teamThuis, teamOut, scoreThuis, scoreOut){
       this.teamThuis   = teamThuis
       this.teamOut     = teamOut
       this.scoreThuis  = scoreThuis
       this.scoreOut    = scoreOut
    }
}

module.exports = Uitslag