package entity;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "car")
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "carBrand")
    private String carBrand;

    @Column(name = "carModel")
    private String carModel ;

    @Column(name = "firstRegisteryDate")
    private LocalDate firstRegisteryDate ;

    @Column(name = "carType ")
    private CarType  carType;

    @Column(name = "purchasePrice")
    private Double purchasePrice ;

    public Car() {
    }

    public Car(String carBrand, String carModel, LocalDate firstRegisteryDate, CarType carType, Double purchasePrice) {
        this.carBrand = carBrand;
        this.carModel = carModel;
        this.firstRegisteryDate = firstRegisteryDate;
        this.carType = carType;
        this.purchasePrice = purchasePrice;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCarBrand() {
        return carBrand;
    }

    public void setCarBrand(String carBrand) {
        this.carBrand = carBrand;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public LocalDate getFirstRegisteryDate() {
        return firstRegisteryDate;
    }

    public void setFirstRegisteryDate(LocalDate firstRegisteryDate) {
        this.firstRegisteryDate = firstRegisteryDate;
    }

    public CarType getCarType() {
        return carType;
    }

    public void setCarType(CarType carType) {
        this.carType = carType;
    }

    public Double getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(Double purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +
                ", carBrand='" + carBrand + '\'' +
                ", carModel='" + carModel + '\'' +
                ", firstRegisteryDate=" + firstRegisteryDate +
                ", carType=" + carType +
                ", purchasePrice=" + purchasePrice +
                '}';
    }
}
