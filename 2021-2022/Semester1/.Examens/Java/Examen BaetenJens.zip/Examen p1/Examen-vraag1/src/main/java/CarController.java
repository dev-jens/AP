import dao.CarDao;
import entity.Car;
import entity.CarType;

import javax.sound.midi.Soundbank;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class CarController {

    public static void main(String[] args) {
        boolean runDealer = true;
        CarDao carDao = new CarDao();

        while(runDealer) {
            welcomeScreen();
            int input = Integer.parseInt(readInput());
            switch (input) {
                case 1:
                    createCar(carDao);

                    break;
                case 2:
                     showCars(carDao);
                    break;
                case 3:
                    System.out.println("application Stopped");
                    runDealer =false;
                    break;
                default:
                    System.out.println("No such option try again");
            }
        }


    }
    static void showCars(CarDao carDao){
        System.out.println("all the cars in the DB");
        List<Car> carList = carDao.getCars();
        carList.forEach(System.out::println);
        System.out.println("total of cars :" + carList.size());
        System.out.println("1. sort On year , 2 Sort on price");
        int input = Integer.parseInt(readInput());
        switch (input){
            case 1:
                carList = carDao.orderByYear();
                break;
            case 2:
                carList = carDao.orderByPrice();
                break;
            default:
                System.out.println();
                break;
        }
        carDao.updateCars(carList);
        System.out.println("-----------------------");
    }

    static void createCar(CarDao carDao){
        System.out.println("give carbrand");
        String brand = readInput();

        System.out.println("give CarModel ");
        String carModel = readInput();

        System.out.println("give firstRegisteryDate ");
        DateTimeFormatter formatOfDate = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate firstRegisteryDate  = LocalDate.parse(readInput(), formatOfDate);

        System.out.println("give carbrand");
        String carTypeInput = readInput().toUpperCase();

        CarType carType = null;
        switch (carTypeInput){
            case "SUV":
                carType = CarType.SUV;
                break;
            case "BREAK":
                carType = CarType.BREAK;
                break;
            case "SEDAN":
                carType = CarType.SEDAN;
                break;
            case "HATCHBACK":
                carType = CarType.HATCHBACK;
                break;
            case "SPORT":
                carType = CarType.SPORT;
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + carType);
        }
        System.out.println("give price");
        double purchasePrice = Double.parseDouble(readInput());

        Car car = new Car(brand,carModel,firstRegisteryDate,carType,purchasePrice);
        carDao.addCar(car);

    }

    static void welcomeScreen(){
        System.out.println("Welcome to the best car dealer");
        System.out.println("Choose action \n" +
                " 1. Add a car           \n" +
                " 2. Show inventory      \n" +
                " 3. Stop\n");

    }


    static String readInput(){
        Scanner input = new Scanner(System.in);
        return input.nextLine() ;
    }
}
