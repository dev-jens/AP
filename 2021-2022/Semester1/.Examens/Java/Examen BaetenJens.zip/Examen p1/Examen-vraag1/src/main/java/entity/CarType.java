package entity;

public enum CarType {
    SUV, BREAK, SEDAN, HATCHBACK, SPORT
}
