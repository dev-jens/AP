package exam;

import java.util.Objects;

public class Movie implements Comparable<Movie>{

	private String title;
	private String director;
	private String leadActor;
	private Integer publishYear;
	private Genre genre;

	public Movie(String title, String director, String leadActor, Integer publishYear, Genre genre) {
		super();
		this.title = title;
		this.director = director;
		this.leadActor = leadActor;
		this.publishYear = publishYear;
		this.genre = genre;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getLeadActor() {
		return leadActor;
	}

	public void setLeadActor(String leadActor) {
		this.leadActor = leadActor;
	}

	public Integer getPublishYear() {
		return publishYear;
	}

	public void setPublishYear(Integer publishYear) {
		this.publishYear = publishYear;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "Movie [title=" + title + ", director=" + director + ", leadActor=" + leadActor + ", publishYear="
				+ publishYear + ", genre=" + genre + "]";
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Movie)) return false;
		Movie movie = (Movie) o;
		return getTitle().equals(movie.getTitle()) && getDirector().equals(movie.getDirector()) && getLeadActor().equals(movie.getLeadActor()) && getPublishYear().equals(movie.getPublishYear()) && getGenre() == movie.getGenre();
	}

	@Override
	public int hashCode() {
		return Objects.hash(getTitle(), getDirector(), getLeadActor(), getPublishYear(), getGenre());
	}

	@Override
	public int compareTo(Movie o) {
		if (this.getDirector() == null){
			return this.getLeadActor().compareTo(o.getLeadActor());
		}
		return this.getDirector().compareTo(o.getDirector());
	}
}
