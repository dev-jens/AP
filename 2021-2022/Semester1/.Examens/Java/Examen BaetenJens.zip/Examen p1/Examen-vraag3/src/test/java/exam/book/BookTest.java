package exam.book;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


public class BookTest {

    @Test
    void createBookUtil(){
        BookUtil bookUtil = new BookUtil();
        assertEquals(0,bookUtil.getBooks().size());

    }
    @Test
    void addBookToStockWhereIdIsNull(){
        BookUtil bookUtil = new BookUtil();
        bookUtil.addBookToStock(null,"boekboek",20.9,5);
        assertEquals(0,bookUtil.getBooks().size());

    }
    @Test
    void addBookToStockThatDoesNotExists(){
        BookUtil bookUtil = new BookUtil();
        bookUtil.addBookToStock("1234","boekboek",20.9,5);
        assertEquals(1,bookUtil.getBooks().size());

    }
    @Test
    void addBookToStockThatExists(){
        BookUtil bookUtil = new BookUtil();
        bookUtil.addBookToStock("1234","boekboek",20.9,5);
        bookUtil.addBookToStock("1234","boekboek",22,5);
        assertEquals(1,bookUtil.getBooks().size());
        assertNotEquals(2,bookUtil.getBooks().size());

    }
    @Test
    void checkIfyouCanSellUnexsistingBook(){
        BookUtil bookUtil = new BookUtil();
        try {
            assertFalse(bookUtil.sellBook("1234",1));
        }catch (OutOfStockException e){
            e.getMessage();
        }
    }
    @Test
    void checkIfYouCanSellExsistingBookWithNotEnoughStock(){
        BookUtil bookUtil = new BookUtil();
        bookUtil.addBookToStock("1234","boekBoek",20,5);
        try {
            String mess = "No enough stock! Check id:1234";
            assertEquals(mess, bookUtil.sellBook("1234", 10));
        }catch (OutOfStockException e){
            e.getMessage();
        }

    }

    @Test
    void checkIfYouCanSellExsistingBook(){
        BookUtil bookUtil = new BookUtil();
        bookUtil.addBookToStock("1234","boekBoek",20,5);
        try {
            assertTrue(bookUtil.sellBook("1234",1));
        }catch (OutOfStockException e){
            e.getMessage();
        }
    }
    @Test
    void GetBookToString() {
        Book book = new Book("1234","boek",20.0,2);
        String infoString = "Book [id=1234, name=boek, price=20.0, stockAmount=2]";
        assertEquals(infoString ,book.toString());
    }
    @Test
    void OutOfStock(){
        BookUtil bookUtil = new BookUtil();
        bookUtil.addBookToStock("1234","boek",20.0,0);
        List<String> idList = new ArrayList<>();
        idList.add("1234");
        assertEquals(1,bookUtil.getOutOfStockIds().size());

    }
    @Test
    void createBook(){
        Book book =new Book("124","boek",20.0,2);

        assertEquals("124", book.getId());
        assertEquals("boek", book.getName());
        assertEquals(20.0, book.getPrice());
        assertEquals(2,book.getStockAmount());
    }
    @Test
    void BookInfo(){
        BookUtil bookUtil = new BookUtil();
        assertNull(bookUtil.getBookInfo("1234"));
    }
}
